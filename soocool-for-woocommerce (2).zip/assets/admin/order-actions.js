(function () {
  var config = window.sooCoolOrderActions || {};
  var actionMessages = config.messages || {};
  var bulkMessages = config.bulkMessages || {};
  var confirmedSubmits = typeof WeakMap === 'function' ? new WeakMap() : null;

  function closest(element, selector) {
    return element && element.closest ? element.closest(selector) : null;
  }

  function eventButton(event) {
    return event && event.target ? closest(event.target, 'button, input[type="submit"], input[type="button"], a.button') : null;
  }

  function stopAction(event) {
    if (!event) {
      return false;
    }

    event.preventDefault();
    event.stopPropagation();
    event.returnValue = false;
    if (typeof event.stopImmediatePropagation === 'function') {
      event.stopImmediatePropagation();
    }
    return false;
  }

  function ask(message, event) {
    if (!message) {
      return true;
    }

    return window.confirm(message) ? true : stopAction(event);
  }

  function selectedBulkAction(form) {
    if (!form || !form.querySelector) {
      return '';
    }

    var select = form.querySelector('select[name="action"]');
    var action = select ? select.value : '';
    if (!action || action === '-1') {
      select = form.querySelector('select[name="action2"]');
      action = select ? select.value : '';
    }

    return action && action !== '-1' ? action : '';
  }

  function selectedOrderAction(scope) {
    var root = scope && scope.querySelector ? scope : document;
    var select = root.querySelector('select[name="wc_order_action"]');
    if (!select && root !== document) {
      select = document.querySelector('select[name="wc_order_action"]');
    }
    return select ? select.value : '';
  }

  function orderActionContext(event) {
    var button = eventButton(event);
    if (!button) {
      return null;
    }

    var form = button.form || closest(button, 'form');
    var action = selectedOrderAction(form || document);
    if (!actionMessages[action]) {
      return null;
    }

    return {
      form: form,
      action: action,
      message: actionMessages[action]
    };
  }

  function bulkActionContext(event) {
    var button = eventButton(event);
    var form = button ? (button.form || closest(button, 'form')) : event && event.target;
    if (!form || !form.querySelector || !form.querySelector('select[name="action"], select[name="action2"]')) {
      return null;
    }

    var action = selectedBulkAction(form);
    if (!bulkMessages[action]) {
      return null;
    }

    return {
      form: form,
      action: action,
      message: bulkMessages[action]
    };
  }

  function rememberSubmit(context) {
    if (confirmedSubmits && context.form) {
      confirmedSubmits.set(context.form, context.action);
    }
  }

  function confirmedSubmit(form, action) {
    if (!confirmedSubmits || !form) {
      return false;
    }

    if (confirmedSubmits.get(form) !== action) {
      return false;
    }

    confirmedSubmits.delete(form);
    return true;
  }

  function confirmClick(event) {
    var context = orderActionContext(event) || bulkActionContext(event);
    if (!context) {
      return true;
    }

    if (!ask(context.message, event)) {
      return false;
    }

    rememberSubmit(context);
    return true;
  }

  function confirmSubmit(event) {
    var form = event && event.target;
    if (!form || !form.querySelector) {
      return true;
    }

    var orderAction = selectedOrderAction(form);
    if (actionMessages[orderAction]) {
      if (confirmedSubmit(form, orderAction)) {
        return true;
      }
      return ask(actionMessages[orderAction], event);
    }

    var bulkAction = selectedBulkAction(form);
    if (bulkMessages[bulkAction]) {
      if (confirmedSubmit(form, bulkAction)) {
        return true;
      }
      return ask(bulkMessages[bulkAction], event);
    }

    return true;
  }

  document.addEventListener('click', confirmClick, true);
  document.addEventListener('submit', confirmSubmit, true);
}());
