(function () {
  var dateFieldName = 'soocool_requested_delivery_date';
  var timeFieldName = 'soocool_requested_delivery_time_slot';

  function closestRoot(element) {
    return element && element.closest ? element.closest('.soocool-delivery-options') : null;
  }

  function selectedDate(root) {
    return root ? root.querySelector('input[name="' + dateFieldName + '"]:checked') : null;
  }

  function selectedTime(root) {
    return root ? root.querySelector('input[name="' + timeFieldName + '"]:checked') : null;
  }

  function setExpanded(root, expanded) {
    if (!root) {
      return;
    }

    var panel = root.querySelector('[data-soocool-time-slots]');
    var button = root.querySelector('[data-soocool-delivery-change]');

    root.classList.toggle('is-time-collapsed', !expanded);
    if (panel) {
      panel.setAttribute('aria-hidden', expanded ? 'false' : 'true');
    }
    if (button) {
      button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    }
  }

  function resetMoreButton(group) {
    if (!group) {
      return;
    }

    var button = group.querySelector('[data-soocool-time-more]');
    group.classList.remove('is-expanded');
    if (button) {
      button.setAttribute('aria-expanded', 'false');
      button.textContent = button.getAttribute('data-more-label') || 'Meer dagdelen tonen';
    }
  }

  function checkedTimeSignature(input) {
    if (!input) {
      return null;
    }

    return {
      value: input.value || '',
      label: input.getAttribute('data-time-label') || ''
    };
  }

  function findMatchingTimeInput(group, signature) {
    if (!group || !signature) {
      return null;
    }

    var inputs = group.querySelectorAll('input[name="' + timeFieldName + '"]:not(:disabled)');
    var labelFallback = null;

    for (var index = 0; index < inputs.length; index++) {
      if (signature.value && inputs[index].value === signature.value) {
        return inputs[index];
      }

      if (!labelFallback && signature.label && inputs[index].getAttribute('data-time-label') === signature.label) {
        labelFallback = inputs[index];
      }
    }

    return labelFallback;
  }

  function updateTimeGroups(root, changedDate) {
    var currentTime = changedDate ? checkedTimeSignature(selectedTime(root)) : null;
    var dateInput = selectedDate(root);
    var selectedDateValue = dateInput ? dateInput.value : '';
    var groups = root ? root.querySelectorAll('[data-soocool-time-date]') : [];
    var activeGroupElement = null;

    Array.prototype.forEach.call(groups, function (group) {
      var active = selectedDateValue && group.getAttribute('data-soocool-time-date') === selectedDateValue;
      group.hidden = !active;
      group.setAttribute('aria-hidden', active ? 'false' : 'true');

      if (active) {
        activeGroupElement = group;
      } else {
        resetMoreButton(group);
        if (changedDate) {
          var checked = group.querySelector('input[name="' + timeFieldName + '"]:checked');
          if (checked) {
            checked.checked = false;
          }
        }
      }
    });

    if (changedDate && activeGroupElement) {
      var match = findMatchingTimeInput(activeGroupElement, currentTime);
      if (match) {
        match.checked = true;
      }
      resetMoreButton(activeGroupElement);
    }
  }

  function updateNotice(root) {
    if (!root) {
      return;
    }

    var dateInput = selectedDate(root);
    var timeInput = selectedTime(root);
    var target = root.querySelector('[data-soocool-delivery-selected]');
    var alert = root.querySelector('.soocool-delivery-options__alert');

    if (!target) {
      return;
    }

    if (!dateInput || !timeInput) {
      target.textContent = '';
      root.classList.remove('has-selection');
      if (alert) {
        alert.hidden = true;
        alert.setAttribute('aria-hidden', 'true');
      }
      return;
    }

    var dateLabel = dateInput.getAttribute('data-delivery-label') || '';
    var timeLabel = timeInput.getAttribute('data-time-label') || '';
    var label = dateLabel && timeLabel ? dateLabel + ', ' + timeLabel : '';

    target.textContent = label;
    root.classList.toggle('has-selection', !!label);
    if (alert) {
      alert.hidden = !label;
      alert.setAttribute('aria-hidden', label ? 'false' : 'true');
    }
  }

  function deliveryMonths(root) {
    var days = root ? root.querySelectorAll('[data-soocool-delivery-month]') : [];
    var seen = {};
    var months = [];

    Array.prototype.forEach.call(days, function (day) {
      var key = day.getAttribute('data-soocool-delivery-month') || '';
      if (!key || seen[key]) {
        return;
      }

      seen[key] = true;
      months.push({
        key: key,
        label: day.getAttribute('data-soocool-delivery-month-label') || key
      });
    });

    return months;
  }

  function monthIndex(months, key) {
    for (var index = 0; index < months.length; index++) {
      if (months[index].key === key) {
        return index;
      }
    }

    return -1;
  }

  function selectedMonth(root) {
    var checked = selectedDate(root);
    var day = checked && checked.closest ? checked.closest('[data-soocool-delivery-month]') : null;

    return day ? day.getAttribute('data-soocool-delivery-month') || '' : '';
  }

  function setActiveMonth(root, monthKey) {
    var months = deliveryMonths(root);
    if (!root || !months.length) {
      return;
    }

    var index = monthIndex(months, monthKey);
    if (index < 0) {
      index = monthIndex(months, root.getAttribute('data-soocool-active-month') || '');
    }
    if (index < 0) {
      index = 0;
    }

    var month = months[index];
    root.setAttribute('data-soocool-active-month', month.key);

    Array.prototype.forEach.call(root.querySelectorAll('[data-soocool-delivery-month]'), function (day) {
      var visible = day.getAttribute('data-soocool-delivery-month') === month.key;
      day.hidden = !visible;
      day.setAttribute('aria-hidden', visible ? 'false' : 'true');
    });

    var label = root.querySelector('[data-soocool-month-label]');
    if (label) {
      label.textContent = month.label;
    }

    var picker = root.querySelector('[data-soocool-delivery-picker]');
    if (picker) {
      picker.setAttribute('aria-label', 'Beschikbare bezorgdagen voor ' + month.label);
    }

    var nav = root.querySelector('[data-soocool-month-nav]');
    if (nav) {
      nav.hidden = months.length < 2;
      nav.setAttribute('aria-hidden', months.length < 2 ? 'true' : 'false');
    }

    var previous = root.querySelector('[data-soocool-month-prev]');
    var next = root.querySelector('[data-soocool-month-next]');
    if (previous) {
      previous.disabled = index <= 0;
    }
    if (next) {
      next.disabled = index >= months.length - 1;
    }
  }

  function updateMonthPicker(root) {
    setActiveMonth(root, selectedMonth(root));
  }

  function moveMonth(root, direction) {
    var months = deliveryMonths(root);
    if (!root || months.length < 2) {
      return;
    }

    var index = monthIndex(months, root.getAttribute('data-soocool-active-month') || '');
    if (index < 0) {
      index = 0;
    }

    var nextIndex = Math.max(0, Math.min(months.length - 1, index + direction));
    setActiveMonth(root, months[nextIndex].key);
  }

  function updateAll() {
    var blocks = document.querySelectorAll('.soocool-delivery-options');
    Array.prototype.forEach.call(blocks, function (root) {
      updateMonthPicker(root);
      updateTimeGroups(root, false);
      updateNotice(root);
      setExpanded(root, !root.classList.contains('is-time-collapsed'));
    });
  }

  function triggerCheckoutUpdate() {
    if (window.jQuery) {
      window.jQuery(document.body).trigger('update_checkout');
    }
  }

  document.addEventListener('change', function (event) {
    var input = event.target;
    if (!input || (input.name !== dateFieldName && input.name !== timeFieldName)) {
      return;
    }

    var root = closestRoot(input);
    if (!root) {
      return;
    }

    if (input.name === dateFieldName) {
      setActiveMonth(root, selectedMonth(root));
      updateTimeGroups(root, true);
      updateNotice(root);
      setExpanded(root, true);
      triggerCheckoutUpdate();
      return;
    }

    updateNotice(root);
    setExpanded(root, false);
    triggerCheckoutUpdate();
  });

  document.addEventListener('click', function (event) {
    var previousMonthButton = event.target.closest ? event.target.closest('[data-soocool-month-prev]') : null;
    if (previousMonthButton) {
      moveMonth(closestRoot(previousMonthButton), -1);
      return;
    }

    var nextMonthButton = event.target.closest ? event.target.closest('[data-soocool-month-next]') : null;
    if (nextMonthButton) {
      moveMonth(closestRoot(nextMonthButton), 1);
      return;
    }

    var changeButton = event.target.closest ? event.target.closest('[data-soocool-delivery-change]') : null;
    if (changeButton) {
      var changeRoot = closestRoot(changeButton);
      setExpanded(changeRoot, true);
      return;
    }

    var moreButton = event.target.closest ? event.target.closest('[data-soocool-time-more]') : null;
    if (!moreButton) {
      return;
    }

    var group = moreButton.closest('[data-soocool-time-date]');
    if (!group) {
      return;
    }

    var expanded = !group.classList.contains('is-expanded');
    group.classList.toggle('is-expanded', expanded);
    moreButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    moreButton.textContent = expanded
      ? (moreButton.getAttribute('data-less-label') || 'Minder tonen')
      : (moreButton.getAttribute('data-more-label') || 'Meer dagdelen tonen');
  });

  document.addEventListener('DOMContentLoaded', updateAll);

  if (window.jQuery) {
    window.jQuery(document.body).on('updated_checkout', updateAll);
  }
}());
